#include<bits/stdc++.h>
#define ll long long int
#define pb push_back
using namespace std;
vector<ll>page,block,counter;
ll tot_page,tot_block;
ll position()
{
    ll mn=counter[0],pos;
    for(ll i=1; i<tot_block; i++)
    {
        if(mn>counter[i])
            pos=i;
    }
    return pos;
}
int main()
{
    cout<<"Enter total page & number of block"<<endl;
    while(cin>>tot_page>>tot_block)
    {
        page.clear();
        block.clear();
        counter.clear();
        ll x;
        cout<<"Enter page reference"<<endl;
        for(ll i=0; i<tot_page; i++)
        {
            cin>>x;
            page.pb(x);
        }
        for(ll i=0; i<tot_block; i++)
        {
            counter.pb(0);
            block.pb(0);
        }
        ll cnt=0,pagefault=0;
        cout<<"Final output is showing below\n"<<endl;
        for(ll i=0; i<tot_page; i++)
        {


            bool flag=false;
            for(ll j=0; j<tot_block; j++)
            {
                if(block[j]==page[i])
                {
                    flag=true;
                    counter[j]=cnt++;
                    break;
                }
            }
            if(flag==false)
            {
                for(ll j=0; j<tot_block; j++)
                {
                    if(block[j]==0)
                    {
                        block[j]=page[i];
                        counter[j]=cnt++;
                        flag=true;
                        pagefault++;
                        break;
                    }
                }
            }
            if(flag==false)
            {
                ll pos=position();
                block[pos]=page[i];
                counter[pos]=cnt++;
                pagefault++;
            }
            for(ll j=0; j<tot_block; j++)cout<<block[j]<<" ";
            cout<<endl;
        }
        ll hit=tot_page-pagefault;
        cout<<"Total fault = "<<pagefault<<" Total Hit = "<<hit<<endl;
    }
}
