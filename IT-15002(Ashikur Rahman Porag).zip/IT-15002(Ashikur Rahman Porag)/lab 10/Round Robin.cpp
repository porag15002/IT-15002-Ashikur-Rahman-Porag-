#include<bits/stdc++.h>
#define ll long long int
#define pb push_back
using namespace std;
struct st
{
    ll proc,arrive,burst;
};
bool cmp(st a,st b)
{
    if(a.arrive==b.arrive)
        return a.burst<b.burst;
    return a.arrive<b.arrive;
}
struct stq
{
    ll pr,tot;
};
struct porag
{
    ll p,wt,tt;
};
bool cmp1(porag a,porag b)
{
    return a.p<b.p;
}
int main()
{
    ll process,quantum;
    cout<<"Enter The process number and Quantum Time"<<endl;
    while(cin>>process>>quantum)
    {
        cout<<"Enter The process id, Arival time, Burst Time"<<endl;
        map<ll,ll>test;
        vector<st>v,rs,res;
        st x;
        ll p;
        for(ll i=0; i<process; i++)
        {
            cin>>p;
            test[p]++;
            x.proc=p;
            cin>>p;
            x.arrive=p;
            cin>>p;
            x.burst=p;
            v.pb(x);
        }
        rs=v;
        sort(v.begin(),v.end(),cmp);
        res=v;
        ll cnt=0,sum=0,chk=0;
        vector<stq>V;
        stq xx;
        x=v[0];
        xx.pr=x.proc;
        xx.tot=0;
        V.pb(xx);
        while(cnt<process)
        {
            for(ll i=0; i<process; i++)
            {
                x=v[i];
                if(chk==1)
                {
                    if(test[x.proc]&&x.arrive<=sum)
                    {
                        if(x.burst>=quantum)
                        {
                            sum+=quantum;
                            v[i].burst-=quantum;
                            xx.pr=x.proc;
                            xx.tot=sum;
                            V.pb(xx);
                        }
                        else
                        {

                            sum+=x.burst;
                            v[i].burst=0;
                            xx.pr=x.proc;
                            xx.tot=sum;
                            test[x.proc]=0;
                            V.pb(xx);
                            cnt++;
                        }
                    }
                }
                else
                {
                    chk=1;
                    if(x.burst>=0)
                    {
                        if(x.burst>=quantum)
                        {
                            sum+=quantum;
                            v[i].burst-=quantum;
                            xx.pr=x.proc;
                            xx.tot=sum;
                            V.pb(xx);

                        }
                        else
                        {
                            sum+=x.burst;
                            v[i].burst=0;
                            xx.pr=x.proc;
                            xx.tot=sum;
                            test[x.proc]=0;
                            V.pb(xx);
                            cnt++;
                        }
                    }
                }
            }
        }
        porag a;
        vector<porag>ans;
        ll m=V.size();
        stq y;
        for(ll i=0; i<process; i++)
        {
            x=res[i];
            a.p=x.proc;
            for(ll j=0; j<m; j++)
            {
                y=V[m-j-1];
                if(x.proc==y.pr)
                {
                    a.tt=y.tot-x.arrive;
                    a.wt=a.tt-x.burst;
                    ans.pb(a);
                    break;
                }
            }
        }
        sort(ans.begin(),ans.end(),cmp1);
        double avg_wait=0.0,avg_turn=0.0;
        for(ll i=0; i<process; i++)
        {
            a=ans[i];
            avg_wait+=(double)a.wt;
            avg_turn+=(double)a.tt;
            cout<<"Process "<<a.p<<" Waiting time = "<<a.wt<<" Turn around time = "<<a.tt<<endl;
        }
        printf("Average Turn around time = %.2lf\n",avg_turn/process);
        printf("Average Waiting time = %.2lf\n",avg_wait/process);
    }
}


