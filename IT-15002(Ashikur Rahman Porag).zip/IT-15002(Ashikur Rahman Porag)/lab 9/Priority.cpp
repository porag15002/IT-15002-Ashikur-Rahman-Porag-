#include<bits/stdc++.h>
#define ll long long int
#define pb push_back
using namespace std;
struct st
{
    ll pr,burst,priority;
};
bool cmp(st a,st b)
{
    if(a.priority==b.priority)return a.pr<b.pr;
    return a.priority<b.priority;
}
struct stq
{
    ll p,start,last;
};
bool cmp1(stq a,stq b)
{
    return a.p<b.p;
}
int main()
{
    ll process;
    cout<<"Enter The process number"<<endl;
    while(cin>>process)
    {
        cout<<"Enter The process id,Burst Time,priority"<<endl;
        vector<st>v,V;
        st a;
        ll x;
        for(ll i=0; i<process; i++)
        {
            cin>>x;
            a.pr=x;
            cin>>x;
            a.burst=x;
            cin>>x;
            a.priority=x;
            v.pb(a);
        }
        V=v;
        sort(v.begin(),v.end(),cmp);

        vector<stq>ans;
        stq xx;
        a=v[0];
        xx.start=0;
        xx.p=a.pr;
        xx.last=a.burst;
        ans.pb(xx);
        ll sum=a.burst;
        for(ll i=1; i<process; i++)
        {
            a=v[i];
            xx.p=a.pr;
            xx.start=sum;
            sum+=a.burst;
            xx.last=sum;
            ans.pb(xx);
        }
        double avg_wait=0.0,avg_turn=0.0;
        for(ll i=0; i<process; i++)
        {
            xx=ans[i];
            avg_turn+=(double)xx.last;
            avg_wait+=(double)xx.start;

        }
        sort(ans.begin(),ans.end(),cmp1);
        for(ll i=0; i<process; i++)
        {
            xx=ans[i];
            cout<<"Process "<<xx.p<<" Waiting time = "<<xx.start<<" Turn around time = "<<xx.last<<endl;
        }
        printf("Average Waiting time = %.2lf\n",avg_wait/process);
        printf("Average Turn around time = %.2lf\n",avg_turn/process);
    }
}

